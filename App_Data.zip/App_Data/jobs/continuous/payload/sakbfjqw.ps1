Invoke-WebRequest "http://dasbox.lorentzvedeler.com:8000" -Body "Hi from Azure"
